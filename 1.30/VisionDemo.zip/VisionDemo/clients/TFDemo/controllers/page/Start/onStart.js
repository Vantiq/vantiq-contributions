    client.data.threshold = 0.5;
    var label = client.getWidget("CurrentModel");
    label.text = 'coco-1.2';