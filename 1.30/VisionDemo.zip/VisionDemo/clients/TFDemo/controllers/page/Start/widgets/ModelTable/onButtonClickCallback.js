	var modelName = extra.dataObject.name;
    var label = client.getWidget("CurrentModel");
    label.text = modelName;