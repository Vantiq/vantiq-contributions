### Using the Baidu Maps API
The BaiduMapsExample Client demonstrates how the BaiduMapViewer widget can be used with the Baidu Maps API libraries to enhance the behavior of a map (such as enabling drawing tools, adding custom markers, drawing heat maps, drawing shapes, etc.)

_Note that this Project only applies if you are running in the Chinese version of VANTIQ, such as https://dev.vantiq.cn. The BaiduMapViewer widget is not available outside of China._
