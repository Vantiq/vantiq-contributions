### Using the Google Maps API
The GoogleMapsExample Client demonstrates how the DynamicMapViewer widget can be used with the Google Maps API libraries to enhance the behavior of a map (such as enabling drawing tools, adding custom markers, drawing heat maps, drawing shapes, etc.)
