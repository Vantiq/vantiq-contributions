    var comp = client.getWidget("trackingRegionComp");
    comp.configuration.loadRegion(parameters);
