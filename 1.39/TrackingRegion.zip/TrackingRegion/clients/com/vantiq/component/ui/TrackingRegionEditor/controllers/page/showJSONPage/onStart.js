    var viewer = client.getWidget("regionJSONViewer");
    viewer.text = parameters;