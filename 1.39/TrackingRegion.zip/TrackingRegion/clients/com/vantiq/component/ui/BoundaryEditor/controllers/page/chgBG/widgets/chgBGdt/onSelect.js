    var docPath = "../.."+extra.content;
    client.data.currentUrl = docPath;
    client.getWidget("imagePreview").url = docPath;
