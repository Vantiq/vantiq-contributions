    if (!this.configuration.isLoadingZones) {
        // load default zones and setup drag & drop.
        this.configuration.loadConvertExpression(null);
    }       