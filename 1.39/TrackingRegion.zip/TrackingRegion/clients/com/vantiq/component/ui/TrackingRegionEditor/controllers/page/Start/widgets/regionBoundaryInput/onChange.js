    console.log("boundary input value changed to "+JSON.stringify(extra));
    client.data.isRegionModified = true;