// Execute Procedure 'com.vantiq.pumpAssistant.sim.deviceReadingHighTempandVibration'
client.execute({}, "com.vantiq.pumpAssistant.sim.deviceReadingHighTempandVibration", function(response){});