// Execute Procedure 'com.vantiq.pumpAssistant.sim.deviceReadingHighTemp'
client.execute({}, "com.vantiq.pumpAssistant.sim.deviceReadingHighTemp", function(response){});