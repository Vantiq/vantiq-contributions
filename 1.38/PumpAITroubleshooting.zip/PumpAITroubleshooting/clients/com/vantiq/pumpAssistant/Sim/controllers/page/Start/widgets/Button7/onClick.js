//  Execute Procedure 'com.vantiq.pumpAssistant.sim.deviceReadingNormal'
client.execute({}, "com.vantiq.pumpAssistant.sim.deviceReadingNormal", function(response){});