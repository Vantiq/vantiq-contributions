//  Execute Procedure 'com.vantiq.pumpAssistant.sim.deviceReadingHighVibration'
client.execute({}, "com.vantiq.pumpAssistant.sim.deviceReadingHighVibration", function(response){});